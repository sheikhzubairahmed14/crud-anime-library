var express = require('express');
var sqlite3 = require('sqlite3').verbose();
var path = require('path');
var bodyParser = require('body-parser');

var db_name = path.join(__dirname, 'data', 'Animes.db');

var db = new sqlite3.Database(db_name, err => {
    if(err){
      return console.error(err.message);
    }

    console.log('SUCCESSFULLY CONNECTED TO DATABSE::::Animes.db');
});

var app = express();

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({extended:false}));

app.get('/', (req, res) => {
    res.redirect('/main');
});

app.get('/main', (req, res) => {
    const sql = `SELECT * FROM Anime ORDER BY Name`;
    db.all(sql, [], (err, rows) => {
        if(err){
           return console.error(err.message);
        }

        res.render('main', {model:rows});
    });
});

app.get('/add', (req, res) => {
    res.render('add', {model:{}});
});

app.post('/add', (req, res) => {
    const anime = [req.body.name, req.body.release_date, req.body.seasons, req.body.type];
    const sql = `INSERT INTO Anime (Name, Release_date, Seasons, Type) VALUES (?, ?, ?, ?)`;
    db.run(sql, anime, err => {
        if(err){
            return console.error(err.message);
        }

        res.redirect('/main');
    });
});

app.get('/edit/:id', (req, res) => {
    const id = req.params.id;
    const sql = `SELECT * FROM Anime WHERE Anime_ID = ?`;
    db.get(sql, id, (err, rows) => {
        if(err){
            return console.error(err.message);
        }

        res.render('edit', {model:rows});
    });
});

app.post('/edit/:id', (req, res) => {
    const id = req.params.id;
    const anime = [req.body.name, req.body.release_date, req.body.seasons, req.body.type, id];
    const sql = `UPDATE Anime SET Name = ?, Release_date = ?, Seasons =?, Type = ? WHERE Anime_ID = ?`;
    db.run(sql, anime, err => {
        if(err){
            return console.error(err.message);
        }

        res.redirect('/main');
    });
});

app.get('/delete/:id', (req, res) => {
    const id = req.params.id;
    const sql = `SELECT * FROM Anime WHERE Anime_ID = ?`;
    db.get(sql, id, (err, rows) => {
        if(err){
            return console.error(err.message);
        }

        res.render('delete.ejs', {model:rows});
    });
});

app.post('/delete/:id', (req, res) => {
    const id = req.params.id;
    const sql = `DELETE FROM Anime WHERE Anime_ID = ?`;
    db.run(sql, id, err => {
        if(err){
            return console.error(err.message);
        }

        res.redirect('/main');
    });
});

app.listen(3000, () => {
    console.log('SERVER STARTED AT::::"localhost:3000"');
});